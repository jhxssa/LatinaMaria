package com.project;

public class Center {

	public static void main(String[] args) {
		
		System.out.println("Product Information: ");
		
		Products p1 = new Products();
				//details
		p1.newName("Apple MacBook Air 2019");
		p1.oneSpec("1.6GHz dual-core processor");
		p1.origPrice(85000);
		p1.getQuantity(2);

		//print
	
		System.out.println("Name of the Product: " + p1.getName());
		System.out.println("Price: P" + p1.getPrice());
		System.out.println("Quantity: " + p1.getQuantity());
		System.out.println("Total: P" + p1.getQuantity() * p1.getPrice() );

	}


	}
